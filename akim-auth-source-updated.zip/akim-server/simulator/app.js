(async function(){
  'use strict';
  const M=window.AkimModel, root=document.getElementById('akim-planner'), q=s=>root.querySelector(s);
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt=n=>n.toLocaleString('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:2});
  const sign=n=>(n>=0?'+':'')+fmt(n), storageKey='akim-app-v1:'+window.AKIM_USER_ID;
  async function api(url,data){const r=await fetch(url,data===undefined?{cache:'no-store'}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const value=await r.json();if(!r.ok)throw Error(value.error||'Ошибка сервера');return value;}
  let city;
  try{city=await api('/api/city');}catch(e){root.textContent=e.message+' Обновите страницу после восстановления доступа.';return;}
  const isAdmin=city.user.role==='admin';
  let history=[{id:1,sheets:city.dataset.sheets,plan:[]}],current=history[0],selected=[0,0],view='plan',sheet='Районы',pending=false,issues=[],readToken=0;
  let savedScenario=null,savedScenarios=[],busy=false,storageAvailable=true;
  const draftKey=storageKey+':'+city.dataset.id;
  try{const plan=JSON.parse(localStorage.getItem(draftKey));if(plan&&M.evaluate(current.sheets,plan).withinLimits)current.plan=plan;}catch{storageAvailable=false;}
  let draft=M.clone(current.sheets);
  function save(){try{localStorage.setItem(draftKey,JSON.stringify(current.plan));storageAvailable=true;}catch{storageAvailable=false;}q('#ap-save-state').textContent=storageAvailable?'Черновик в браузере. Итог сохраняется на сервере кнопкой оценки.':'Черновик не сохранён; итог можно сохранить кнопкой оценки.';}
  function invalidate(){savedScenario=null;q('#ap-server-report').hidden=true;}
  function setBusy(value){busy=value;root.querySelectorAll('button,input,select').forEach(el=>{if(value){if(!('wasDisabled' in el.dataset))el.dataset.wasDisabled=el.disabled?'1':'0';el.disabled=true;}else{el.disabled=el.dataset.wasDisabled==='1';delete el.dataset.wasDisabled;}});q('#ap-analyze').textContent=value?'Сохраняем и анализируем…':'Оценить и сохранить сценарий';}
  function selection(){const m=current.sheets.Мероприятия[selected[0]], d=m.Охват==='Город'?'*':current.sheets.Районы[selected[1]].Район;return {measure:m.Мероприятие,district:d};}
  const same=(a,b)=>a.measure===b.measure&&a.district===b.district;
  function setChoice(enabled){if(busy)return;const choice=selection(),category=current.sheets.Мероприятия.find(m=>m.Мероприятие===choice.measure).Направление,plan=current.plan.filter(p=>enabled?current.sheets.Мероприятия.find(m=>m.Мероприятие===p.measure).Направление!==category:!same(p,choice));if(enabled)plan.push(choice);const next=M.evaluate(current.sheets,plan);if(!next.withinLimits){q('#ap-error').hidden=false;q('#ap-error').textContent=next.spent>next.budget?'Недостаточно бюджета. Уберите другое мероприятие.':'Можно выбрать не более '+next.required+' решений. Уберите одно из выбранных.';return;}invalidate();current.plan=plan;q('#ap-error').hidden=true;render();save();}
  function render(){
    const s=current.sheets,x=M.evaluate(s,current.plan),a=x.after,b=x.before,ds=s.Районы,ms=s.Мероприятия;
    q('#ap-spent').textContent=fmt(x.spent);q('#ap-limit').textContent='Лимит бюджета: '+fmt(x.budget)+' усл. ед.';q('#ap-remaining').textContent='Остаток: '+fmt(x.budget-x.spent);q('#ap-budgetbar').style.width=Math.min(100,x.spent/x.budget*100)+'%';
    q('#ap-score').textContent=fmt(a.score);q('#ap-base').textContent=fmt(b.score);q('#ap-gain').textContent=sign(a.score-b.score);q('#ap-count').textContent=x.count+' / '+x.required;
    q('#ap-coverage').textContent='Направлений: '+x.directions.length+' / 5 · районов: '+x.coverage.length+' / '+ds.length;q('#ap-district-count').textContent='РАЙОНОВ: '+ds.length;
    q('#ap-plan-status').textContent=x.valid?'План готов к оценке':('Предпросмотр · выберите ещё '+(x.required-x.count)+' решений');
    q('#ap-plan thead').innerHTML='<tr><th scope="col">Мероприятие</th>'+ds.map(d=>'<th scope="col">'+esc(d.Район)+'</th>').join('')+'</tr>';
    let html='';
    M.categories.forEach(cat=>{html+='<tr class="ap-category"><td colspan="'+(ds.length+1)+'">'+esc(cat)+'</td></tr>';ms.forEach((m,i)=>{if(m.Направление!==cat)return;html+='<tr><td>'+esc(m.Мероприятие)+'<div class="ap-price">'+fmt(M.num(m.Стоимость))+' ед. · лаг '+m.Лаг+' кв. · '+(m.Охват==='Город'?'весь город':'один район')+'</div></td>';const targets=m.Охват==='Город'?['*']:ds.map(d=>d.Район);targets.forEach((d,j)=>{const active=current.plan.some(p=>same(p,{measure:m.Мероприятие,district:d}));html+='<td'+(d==='*'?' colspan="'+ds.length+'"':'')+'><button class="ap-cell '+(active?'ap-funded':'')+'" data-action="'+i+'" data-district="'+j+'" aria-pressed="'+(selected[0]===i&&(d==='*'||selected[1]===j))+'" aria-label="'+esc(m.Мероприятие+', '+(d==='*'?'весь город':d))+'">'+(active?'✓ В плане':'Выбрать')+(d==='*'?'<span>Одна мера для всех районов</span>':'')+'</button></td>';});html+='</tr>';});});q('#ap-rows').innerHTML=html;
    const c=selection(),m=ms[selected[0]],active=current.plan.some(p=>same(p,c)),factor=(8-M.num(m.Лаг))/8;
    q('#ap-selected-name').textContent=m.Мероприятие;q('#ap-selected-district').textContent=c.district==='*'?'Все районы · оплачивается один раз':c.district+' район';q('#ap-selected-cost').textContent=fmt(M.num(m.Стоимость))+' усл. ед.';q('#ap-selected-effect').textContent=fmt(factor*100)+'% полного эффекта';
    const effect=s.Эффекты.find(e=>e.Мероприятие===c.measure&&e.Район===ds[selected[1]].Район);
    q('#ap-selected-category').innerHTML='Горизонт: 8 кварталов. Задержка: '+m.Лаг+' кв.<br>'+M.keys.map((k,i)=>M.num(effect[k])?esc(k+' · '+M.labels[i])+': '+sign(M.num(effect[k])*factor):'').filter(Boolean).join('<br>')+(c.district==='*'?'<br>Показаны эффекты для района «'+esc(ds[selected[1]].Район)+'». Все районные значения — на вкладке данных.':'');
    root.querySelectorAll('[data-level]').forEach(btn=>btn.setAttribute('aria-pressed',String((btn.dataset.level==='1')===active)));
    const weak=ds[a.district.indexOf(a.worst)].Район;
    q('#ap-advice').innerHTML='<p><strong>'+esc(weak)+' — самый слабый район</strong><br>Индекс: '+fmt(a.worst)+'.</p><p>Изменение городского балла: '+sign(a.score-b.score)+'.<br>Критических показателей: '+a.critical+' (было '+b.critical+').</p><p>Активных синергий по районам: '+x.activeSynergies.length+'.</p><p>Разбор составлен по результатам расчёта, без генеративного ИИ.</p>';
    q('#ap-districts').innerHTML=ds.map((d,i)=>'<section class="ap-box"><h2>'+esc(d.Район)+'</h2><p class="ap-small ap-muted">Доля населения: '+fmt(a.shares[i]*100)+'%</p><div class="ap-big">'+fmt(a.district[i])+' <span class="ap-unit">'+sign(a.district[i]-b.district[i])+'</span></div><div class="ap-track"><div class="ap-fill" style="width:'+a.district[i]+'%"></div></div><p class="ap-small ap-muted">До: '+fmt(b.district[i])+'</p><div class="ap-indicators">'+M.keys.map((k,j)=>'<div class="ap-pair"><span title="'+esc(M.labels[j])+'">'+k+' · '+esc(M.labels[j])+'</span><strong class="'+(x.values[i][j]<40?'ap-critical':'')+'">'+fmt(x.base[i][j])+' → '+fmt(x.values[i][j])+'</strong></div>').join('')+'</div></section>').join('');
    q('#ap-metrics').innerHTML=M.categories.map((cat,i)=>{const k=i*2,w=M.weights[k]+M.weights[k+1];const value=v=>v.reduce((sum,row,d)=>sum+a.shares[d]*(row[k]*M.weights[k]+row[k+1]*M.weights[k+1])/w,0);return '<div class="ap-result-row"><div class="ap-pair"><span>'+cat+'</span><span>'+fmt(value(x.base))+' → '+fmt(value(x.values))+'</span></div><div class="ap-track"><div class="ap-fill" style="width:'+value(x.values)+'%"></div></div></div>';}).join('');
    q('#ap-breakdown').innerHTML='<h2>Из чего складывается балл</h2><div class="ap-equation">0,7 × '+fmt(a.average)+' + 0,3 × '+fmt(a.worst)+' − '+a.critical+' = '+fmt(a.raw)+'</div><p>После ограничения 0–100: <strong>'+fmt(a.score)+'</strong></p><p class="ap-small ap-muted">Числа показаны с округлением; расчёт использует полную точность.</p><div class="ap-separator"></div><p>Вклад изменения среднего: '+sign(.7*(a.average-b.average))+'; худшего района: '+sign(.3*(a.worst-b.worst))+'; штрафов: '+sign(b.critical-a.critical)+'. Поправка ограничения шкалы: '+sign((a.score-a.raw)-(b.score-b.raw))+'.</p><h3 style="margin-top:16px">Синергии</h3>'+(x.activeSynergies.length?x.activeSynergies.map(v=>'<p class="ap-small">'+esc(v.first+' + '+v.second+' · '+v.district)+': '+v.delta.map((v,i)=>v?M.keys[i]+' '+sign(v):'').filter(Boolean).join(', ')+'</p>').join(''):'<p class="ap-small ap-muted">Нет активных пар.</p>');
    q('#ap-plan').hidden=view!=='plan';q('#ap-results').hidden=view!=='results';q('.ap-workspace').hidden=view==='data';q('#ap-data').hidden=view!=='data';['plan','result','data'].forEach(n=>q('#ap-'+n+'-tab').setAttribute('aria-pressed',String(view===(n==='result'?'results':n))));
    q('#ap-current').textContent='Набор '+city.dataset.id.slice(0,8)+' · '+s.Настройки[0]['Название набора'];q('#ap-versions').innerHTML=history.map(h=>'<option value="'+h.id+'" '+(h===current?'selected':'')+'>Версия '+h.id+' · '+esc(h.sheets.Настройки[0]['Название набора'])+'</option>').join('');
    if(busy)setBusy(true);
  }
  function status(message,error=false){q('#ap-import-status').textContent=message;q('#ap-import-status').dataset.error=String(error);}
  function preview(){const data=draft[sheet]||[];q('#ap-import-head').innerHTML='<tr>'+M.headers[sheet].map(h=>'<th scope="col">'+esc(h)+'</th>').join('')+'</tr>';q('#ap-import-body').innerHTML=data.slice(0,100).map(r=>'<tr>'+M.headers[sheet].map(h=>'<td>'+esc(r[h]??'—')+'</td>').join('')+'</tr>').join('');q('#ap-import-count').textContent='Строк: '+data.length;q('#ap-import-help').textContent='Показаны первые '+Math.min(100,data.length)+' строк. '+({Районы:'Показатели 0–100; население используется для расчёта долей.',Мероприятия:'Охват: Район или Город. Лаг: 0–8 кварталов.',Эффекты:'Все пары мероприятие × район обязательны. Отрицательные эффекты допустимы.',Синергии:'Район * — каждый район, где действуют обе меры. Бонус фиксирован и не умножается на лаг.',Настройки:'Горизонт 8 кварталов. Число решений задаёт размер итогового плана.'}[sheet]);root.querySelectorAll('[data-sheet]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.sheet===sheet)));q('#ap-check-districts').textContent=draft.Районы?.length||0;q('#ap-check-actions').textContent=draft.Мероприятия?.length||0;q('#ap-check-errors').textContent=issues.length;q('#ap-apply').disabled=!pending||issues.length>0||!q('#ap-confirm').checked;if(issues.length){q('#ap-import-status').innerHTML='<strong>Исправьте ошибки</strong><ul>'+issues.slice(0,8).map(e=>'<li>'+esc(e)+'</li>').join('')+'</ul><p>Всего ошибок: '+issues.length+'</p>';q('#ap-import-status').dataset.error='true';}}
  let importedPlan=[];
  function stage(s,label,plan=[]){issues=M.validate(s);if(!issues.length){try{if(!Array.isArray(plan)||!M.evaluate(s,plan).withinLimits)throw Error('План превышает ограничения.');}catch(e){issues.push(e.message);}}if(Object.keys(M.headers).some(k=>!Array.isArray(s?.[k]))){pending=false;status(issues.join(' '),true);q('#ap-apply').disabled=true;return;}draft=s;importedPlan=plan;pending=true;q('#ap-confirm').checked=false;status(label+' · '+(issues.length?'Найдены ошибки.':'Данные проверены, но ещё не применены.'));preview();}
  function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  const jsonDownload=(value,name)=>download(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}),name);
  let library;
  function excel(){if(window.XLSX)return Promise.resolve(window.XLSX);if(library)return library;library=new Promise((resolve,reject)=>{const tag=document.createElement('script');tag.src='https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';tag.onload=()=>{if(window.XLSX)resolve(window.XLSX);else{library=null;reject(Error('Модуль Excel недоступен. Используйте JSON или CSV.'));}};tag.onerror=()=>{library=null;reject(Error('Для Excel нужен интернет. JSON и CSV работают без сети.'));};document.head.appendChild(tag);});return library;}
  function parseCSV(text){text=text.replace(/^\uFEFF/,'');const first=text.split(/\r?\n/)[0],delimiter=first.includes(';')?';':',',rows=[];let row=[],value='',inside=false;for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(inside&&text[i+1]==='"'){value+='"';i++;}else inside=!inside;}else if(c===delimiter&&!inside){row.push(value);value='';}else if((c==='\n'||c==='\r')&&!inside){if(c==='\r'&&text[i+1]==='\n')i++;row.push(value);if(row.some(v=>v.trim()))rows.push(row);row=[];value='';}else value+=c;}if(inside)throw Error('CSV: незакрытые кавычки.');row.push(value);if(row.some(v=>v.trim()))rows.push(row);return rows;}
  function fromRows(key,rows){const h=(rows.shift()||[]).map(v=>String(v).trim());if(new Set(h).size!==h.length||M.headers[key].some(k=>!h.includes(k)))throw Error('Лист «'+key+'»: неверные заголовки.');return rows.filter(r=>r.some(v=>String(v??'').trim())).map(r=>Object.fromEntries(M.headers[key].map(k=>[k,typeof r[h.indexOf(k)]==='string'?r[h.indexOf(k)].trim():r[h.indexOf(k)]??''])));}
  root.querySelectorAll('[data-sheet]').forEach(b=>b.onclick=()=>{sheet=b.dataset.sheet;preview();});q('#ap-confirm').onchange=preview;
  q('#ap-demo').onclick=()=>{readToken++;stage(M.seed(),'Демонстрационный набор');};
  q('#ap-json-template').onclick=()=>jsonDownload(M.seed(),'akim-data.json');
  q('#ap-template').onclick=async()=>{try{const X=await excel(),book=X.utils.book_new();Object.keys(M.headers).forEach(k=>X.utils.book_append_sheet(book,X.utils.aoa_to_sheet([M.headers[k],...draft[k].map(r=>M.headers[k].map(h=>r[h]))]),k));download(new Blob([X.write(book,{bookType:'xlsx',type:'array'})]),'akim-data.xlsx');}catch(e){status(e.message,true);}};
  q('#ap-csv-template').onclick=()=>{const quote=v=>'"'+String(v).replace(/"/g,'""')+'"';download(new Blob(['\uFEFF'+[M.headers[sheet],...draft[sheet].map(r=>M.headers[sheet].map(h=>r[h]))].map(r=>r.map(quote).join(';')).join('\r\n')],{type:'text/csv;charset=utf-8'}),sheet+'.csv');};
  q('#ap-upload').onchange=async e=>{const file=e.target.files[0];if(!file)return;const token=++readToken;pending=false;q('#ap-confirm').checked=false;q('#ap-apply').disabled=true;status('Чтение файла…');try{if(file.size>1024*1024)throw Error('Файл больше 1 МБ.');let s,plan=[];if(/\.json$/i.test(file.name)){const value=JSON.parse(await file.text());s=value.sheets||value;plan=value.plan||[];}else if(/\.csv$/i.test(file.name)){const rows=parseCSV(await file.text()),h=rows[0]||[],key=Object.keys(M.headers).find(k=>M.headers[k].every(v=>h.includes(v)));if(!key)throw Error('Не удалось определить лист CSV.');s=M.clone(draft);s[key]=fromRows(key,rows);sheet=key;}else if(/\.xlsx$/i.test(file.name)){const X=await excel(),book=X.read(await file.arrayBuffer(),{type:'array',sheetRows:2003});s={};for(const k of Object.keys(M.headers)){const ws=book.Sheets[k];if(!ws)throw Error('Нет листа «'+k+'».');if(ws['!fullref']&&X.utils.decode_range(ws['!fullref']).e.r>2000)throw Error('Слишком много строк.');s[k]=fromRows(k,X.utils.sheet_to_json(ws,{header:1,defval:''}));}}else throw Error('Поддерживаются JSON, CSV и XLSX.');if(token===readToken)stage(s,file.name,plan);}catch(err){if(token===readToken){issues=[err.message];pending=false;status(err.message,true);preview();}}e.target.value='';};
  q('#ap-apply').onclick=async()=>{if(!isAdmin||!pending||issues.length||!q('#ap-confirm').checked)return;setBusy(true);try{await api('/api/admin/datasets',{sheets:draft});location.reload();}catch(e){status(e.message,true);}finally{setBusy(false);preview();}};
  q('#ap-versions').onchange=e=>{readToken++;current=history.find(h=>h.id===+e.target.value);selected=[0,0];draft=M.clone(current.sheets);pending=false;issues=[];q('#ap-confirm').checked=false;status('Открыта версия '+current.id);render();preview();save();};
  q('#ap-rows').onclick=e=>{const b=e.target.closest('[data-action]');if(b){selected=[+b.dataset.action,+b.dataset.district];q('#ap-error').hidden=true;render();if(window.innerWidth<=950)q('#ap-selected-name').parentElement.scrollIntoView({block:'start',behavior:'smooth'});}};
  q('#ap-levels').onclick=e=>{const b=e.target.closest('[data-level]');if(b)setChoice(b.dataset.level==='1');};
  q('#ap-plan-tab').onclick=()=>{view='plan';render();};q('#ap-result-tab').onclick=()=>{view='results';render();};q('#ap-data-tab').onclick=()=>{view='data';render();preview();};
  q('#ap-analyze').onclick=async()=>{
    const x=M.evaluate(current.sheets,current.plan);
    if(!x.valid){view='plan';render();q('#ap-error').hidden=false;q('#ap-error').textContent='Нужно по одному решению на каждое из пяти направлений в пределах бюджета.';return;}
    setBusy(true);q('#ap-server-status').textContent='Проверяем и сохраняем сценарий на сервере…';
    try{
      if(!savedScenario)savedScenario=(await api('/api/scenarios',{datasetId:city.dataset.id,plan:current.plan,title:q('#ap-title').value||'Мой сценарий'})).scenario;
      showReport(savedScenario);view='results';render();
      q('#ap-server-status').textContent='Сценарий сохранён. Запрашиваем AI-объяснение…';
      savedScenario=(await api('/api/scenarios/'+savedScenario.id+'/analyze',{})).scenario;
      showReport(savedScenario);await loadSaved();q('#ap-server-status').textContent='Сценарий сохранён в PostgreSQL. '+(savedScenario.analysis.status==='ready'?'AI-разбор готов.':savedScenario.analysis.message);
    }catch(e){q('#ap-server-status').textContent=(savedScenario?'Расчёт сохранён. ':'')+e.message;}
    finally{setBusy(false);render();preview();}
  };
  q('#ap-export').onclick=()=>jsonDownload({format:'akim-scenario-v1',sheets:current.sheets,plan:current.plan,datasetId:city.dataset.id,result:M.evaluate(current.sheets,current.plan),serverScenario:savedScenario},'akim-scenario.json');
  let undo=[],undoVersion=null;q('#ap-reset').onclick=()=>{undo=M.clone(current.plan);undoVersion=current.id;invalidate();current.plan=[];q('#ap-undo').hidden=!undo.length;q('#ap-error').hidden=true;render();save();};q('#ap-undo').onclick=()=>{if(undoVersion!==current.id){q('#ap-undo').hidden=true;return;}const restored=M.evaluate(current.sheets,undo);if(!restored.withinLimits)return;invalidate();current.plan=undo;q('#ap-undo').hidden=true;render();save();};
  function showReport(row){
    const r=row.result,rec=row.recommendation;q('#ap-server-report').hidden=false;
    q('#ap-server-summary').textContent=row.title+' · Astana Quality of Life Score: '+fmt(r.after.score)+' · бюджет '+fmt(r.spent)+' / '+fmt(r.budget)+' · формула '+row.formula_version;
    q('#ap-saved-plan').innerHTML=row.plan.map(p=>'<li>'+esc(p.measure)+' — '+esc(p.district==='*'?'Весь город':p.district)+'</li>').join('');
    q('#ap-ai').replaceChildren();
    if(row.analysis?.status==='ready'){
      const labels={strengths:'Сильные стороны',risks:'Риски и отрицательные эффекты',tradeoffs:'Основные компромиссы',improvement:'Возможное улучшение'};
      for(const [key,label] of Object.entries(labels)){const h=document.createElement('h3'),p=document.createElement('p');h.textContent=label;p.textContent=row.analysis.sections[key];q('#ap-ai').append(h,p);}
    }else q('#ap-ai').textContent=row.analysis?.message||'AI-объяснение ещё не получено.';
    q('#ap-recommendation').textContent=rec?'Проверенная замена: '+rec.old.measure+' ('+rec.old.district+') → '+rec.choice.measure+' ('+rec.choice.district+'). Новый Score: '+fmt(rec.result.after.score)+' ('+sign(rec.gain)+'), бюджет: '+fmt(rec.result.spent)+'. Это лучший найденный вариант одной замены, не глобальный оптимум.':'Улучшение одной допустимой заменой не найдено.';
    q('#ap-use-recommendation').hidden=!rec||row.dataset_id!==city.dataset.id;
  }
  async function loadSaved(){
    savedScenarios=(await api('/api/scenarios')).scenarios;
    const opts='<option value="">Выберите сценарий</option>'+savedScenarios.map(r=>'<option value="'+r.id+'">'+esc(r.title)+' · '+fmt(r.result.after.score)+' · '+new Date(r.created_at).toLocaleString('ru-RU')+'</option>').join('');
    q('#ap-compare-a').innerHTML=opts;q('#ap-compare-b').innerHTML=opts;
  }
  function compare(){
    const a=savedScenarios.find(r=>r.id===q('#ap-compare-a').value),b=savedScenarios.find(r=>r.id===q('#ap-compare-b').value);
    if(!a||!b){q('#ap-comparison').textContent='Выберите два сохранённых сценария.';return;}
    if(a.dataset_id!==b.dataset_id||a.formula_version!==b.formula_version){q('#ap-comparison').textContent='Нельзя сравнивать разные наборы данных или версии формулы.';return;}
    q('#ap-comparison').innerHTML='<div class="ap-scroll"><table><thead><tr><th>Показатель</th><th>'+esc(a.title)+'</th><th>'+esc(b.title)+'</th></tr></thead><tbody>'+[
      ['Score',a.result.after.score,b.result.after.score],['Средний индекс',a.result.after.average,b.result.after.average],['Худший район',a.result.after.worst,b.result.after.worst],['Критические показатели',a.result.after.critical,b.result.after.critical],['Расходы',a.result.spent,b.result.spent]
    ].map(([label,x,y])=>'<tr><td>'+label+'</td><td>'+fmt(x)+'</td><td>'+fmt(y)+'</td></tr>').join('')+'</tbody></table></div>';
  }
  q('#ap-compare-a').onchange=q('#ap-compare-b').onchange=compare;
  q('#ap-open-saved').onclick=()=>{
    const row=savedScenarios.find(r=>r.id===q('#ap-compare-a').value);if(!row)return;
    if(row.dataset_id!==city.dataset.id){q('#ap-comparison').textContent='Этот сценарий из другого раунда: сравните его с тем же набором или скачайте JSON.';return;}
    current.plan=M.clone(row.plan);savedScenario=row;q('#ap-title').value=row.title;view='results';render();showReport(row);save();
  };
  q('#ap-download-saved').onclick=()=>{const row=savedScenarios.find(r=>r.id===q('#ap-compare-a').value);if(row)jsonDownload(row,'akim-saved-scenario.json');};
  q('#ap-use-recommendation').onclick=()=>{if(!savedScenario?.recommendation)return;current.plan=M.clone(savedScenario.recommendation.plan);invalidate();view='plan';render();save();};
  q('#ap-print').onclick=()=>window.print();
  q('#ap-title').onchange=invalidate;
  q('#ap-dataset-role').textContent=isAdmin?'ОРГАНИЗАТОР · ОБЩИЙ НАБОР':'УЧАСТНИК · ДАННЫЕ ЗАКРЕПЛЕНЫ';
  if(!isAdmin){q('.ap-drop').hidden=true;q('#ap-confirm').closest('section').hidden=true;q('.ap-import-steps').hidden=true;}
  q('#ap-versions').closest('section').hidden=true;
  q('#ap-server-status').textContent='Общий набор загружен с сервера. '+(city.aiConfigured?'AI настроен.':'AI не настроен: расчёт и сохранение доступны.');
  render();preview();save();
  try{await loadSaved();}catch(e){q('#ap-server-status').textContent=e.message;}

})();



