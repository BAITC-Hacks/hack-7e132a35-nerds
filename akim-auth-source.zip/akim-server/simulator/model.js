/* Deterministic simulation engine. All effects use points on a 0–100 scale. */
(function (host) {
  'use strict';
  const keys = ['T1','T2','E1','E2','S1','S2','B1','B2','C1','C2'];
  const weights = [.10,.10,.09,.11,.11,.11,.09,.09,.10,.10];
  const labels = ['Доступность транспорта','Свобода дорог','Зелёные зоны','Качество воздуха','Доступность образования','Доступность досуга','Безопасность улиц','Безопасность движения','Доступность услуг','Чистота города'];
  const categories = ['Транспорт','Озеленение и экология','Социальная сфера','Безопасность','Сервисы'];
  const headers = {
    Районы: ['Район','Население',...keys],
    Мероприятия: ['Мероприятие','Направление','Стоимость','Лаг','Охват'],
    Эффекты: ['Мероприятие','Район',...keys],
    Синергии: ['Мера 1','Мера 2','Район',...keys],
    Настройки: ['Название набора','Бюджет','Число решений']
  };
  const num = x => typeof x === 'number' ? x : Number(String(x).trim().replace(',','.'));
  const clip = x => Math.min(100,Math.max(0,x));
  const clone = x => JSON.parse(JSON.stringify(x));
  function validate(s) {
    const errors=[];
    if(!s || typeof s!=='object') return ['Ожидается объект с листами данных.'];
    for(const [name,cols] of Object.entries(headers)) {
      if(!Array.isArray(s[name])) {errors.push('Нет листа «'+name+'».');continue;}
      if(name!=='Синергии' && !s[name].length) errors.push('Лист «'+name+'» пуст.');
      if(s[name].length>2000) errors.push('На листе «'+name+'» больше 2000 строк.');
      s[name].forEach((r,i)=>{if(!r || typeof r!=='object') {errors.push(name+': неверная строка '+(i+2));return;} cols.forEach(k=>{if(r[k]===undefined || r[k]===null || String(r[k]).trim()==='') errors.push(name+', строка '+(i+2)+': не заполнено «'+k+'».');});});
    }
    if(errors.length) return errors;
    const ds=s.Районы, ms=s.Мероприятия;
    if(ds.length>20 || ms.length>50) errors.push('Допустимо до 20 районов и 50 мероприятий.');
    function numeric(r,k,min,max,where,integer=false){const n=num(r[k]);if(!Number.isFinite(n)||n<min||n>max||(integer&&!Number.isInteger(n)))errors.push(where+': «'+k+'» должно быть '+(integer?'целым ':'')+'числом от '+min+' до '+max+'.');}
    function unique(rows,k){const seen=new Set();rows.forEach(r=>{const n=String(r[k]).trim().toLowerCase();if(seen.has(n)) errors.push('Повтор: '+r[k]);seen.add(n);if(String(r[k]).length>100||r[k]==='*') errors.push('Недопустимое название: '+r[k]);});}
    unique(ds,'Район');unique(ms,'Мероприятие');
    ds.forEach(r=>{numeric(r,'Население',1,1e9,r.Район,true);keys.forEach(k=>numeric(r,k,0,100,r.Район));});
    ms.forEach(r=>{numeric(r,'Стоимость',1,1e6,r.Мероприятие);numeric(r,'Лаг',0,8,r.Мероприятие,true);if(!categories.includes(r.Направление))errors.push('Неизвестное направление: '+r.Направление);if(!['Район','Город'].includes(r.Охват))errors.push('Охват должен быть «Район» или «Город».');});
    const dn=new Set(ds.map(r=>r.Район)), mn=new Set(ms.map(r=>r.Мероприятие)), pairs=new Set();
    s.Эффекты.forEach(r=>{if(!mn.has(r.Мероприятие)||!dn.has(r.Район))errors.push('Эффекты: неизвестное мероприятие или район.');const pair=JSON.stringify([r.Мероприятие,r.Район]);if(pairs.has(pair))errors.push('Повтор эффекта: '+r.Мероприятие+' / '+r.Район);pairs.add(pair);keys.forEach(k=>numeric(r,k,-100,100,'Эффекты'));});
    ms.forEach(m=>ds.forEach(d=>{if(!pairs.has(JSON.stringify([m.Мероприятие,d.Район])))errors.push('Нет эффекта: '+m.Мероприятие+' / '+d.Район);}));
    const sy=new Set();s.Синергии.forEach(r=>{if(!mn.has(r['Мера 1'])||!mn.has(r['Мера 2'])||r['Мера 1']===r['Мера 2']||(!dn.has(r.Район)&&r.Район!=='*'))errors.push('Синергии: неверная пара мер или район.');keys.forEach(k=>numeric(r,k,-100,100,'Синергии'));const pair=JSON.stringify([[r['Мера 1'],r['Мера 2']].sort(),r.Район]);if(sy.has(pair))errors.push('Повтор синергии.');sy.add(pair);});
    if(s.Настройки.length!==1)errors.push('В настройках нужна ровно одна строка.');
    s.Настройки.forEach(r=>{numeric(r,'Бюджет',1,1e6,'Настройки');numeric(r,'Число решений',1,50,'Настройки',true);});
    return errors;
  }
  function aggregate(values,population) {
    const district=values.map(row=>row.reduce((sum,v,k)=>sum+v*weights[k],0));
    const total=population.reduce((a,b)=>a+b,0), shares=population.map(p=>p/total);
    const average=district.reduce((sum,v,d)=>sum+v*shares[d],0), worst=Math.min(...district);
    const critical=values.flat().filter(v=>v<40).length;
    const raw=.7*average+.3*worst-critical;
    return {district,shares,average,worst,critical,raw,score:clip(raw)};
  }
  function evaluate(s,plan=[]) {
    const errors=validate(s);if(errors.length)throw new Error(errors.join('\n'));
    const districts=s.Районы.map(r=>r.Район), population=s.Районы.map(r=>num(r.Население));
    const base=s.Районы.map(r=>keys.map(k=>num(r[k]))), values=clone(base);
    const used=new Set(), contributions=[], activeSynergies=[];let spent=0;
    const coverage=new Set();
    for(const choice of plan) {
      const m=s.Мероприятия.find(r=>r.Мероприятие===choice.measure);
      if(!m)throw new Error('Неизвестная мера в плане.');
      if(m.Охват==='Город' && choice.district!=='*')throw new Error('Городская мера должна охватывать весь город.');
      if(m.Охват==='Район' && !districts.includes(choice.district))throw new Error('Укажите район мероприятия.');
      const id=JSON.stringify([choice.measure,choice.district]);if(used.has(id))throw new Error('Повтор решения в плане.');used.add(id);
      spent+=num(m.Стоимость);
      const factor=(8-num(m.Лаг))/8;
      districts.forEach((name,d)=>{if(m.Охват==='Город'||choice.district===name){coverage.add(d);const e=s.Эффекты.find(r=>r.Мероприятие===choice.measure&&r.Район===name);const delta=keys.map(k=>num(e[k])*factor);delta.forEach((v,k)=>values[d][k]+=v);contributions.push({measure:choice.measure,district:name,delta,factor});}});
    }
    const applies=(measure,d)=>plan.some(p=>p.measure===measure&&(p.district==='*'||p.district===d));
    s.Синергии.forEach((r,index)=>districts.forEach((d,di)=>{if((r.Район==='*'||r.Район===d)&&applies(r['Мера 1'],d)&&applies(r['Мера 2'],d)){const delta=keys.map(k=>num(r[k]));delta.forEach((v,k)=>values[di][k]+=v);activeSynergies.push({index,district:d,first:r['Мера 1'],second:r['Мера 2'],delta});}}));
    const clipped=values.map(row=>row.map(clip)), before=aggregate(base,population), after=aggregate(clipped,population);
    const budget=num(s.Настройки[0].Бюджет), required=num(s.Настройки[0]['Число решений']);
    return {base,values:clipped,before,after,spent,budget,required,count:plan.length,coverage:[...coverage],contributions,activeSynergies,valid:spent<=budget&&plan.length===required,withinLimits:spent<=budget&&plan.length<=required};
  }
  function seed() {
    const rows=[[43,49,52,57,51,54,61,48,57,53],[68,58,45,53,72,67,65,56,70,64],[46,51,48,50,38,44,57,52,51,55],[52,55,61,56,48,50,39,49,56,51],[57,54,53,59,55,52,58,54,62,57]];
    const names=['Северный','Центральный','Восточный','Южный','Западный'];
    const specs=[
      ['Автобусные полосы',0,20,2,'Район',{T1:12,T2:7}],['Умные остановки',0,10,1,'Район',{T1:7,C1:2}],['Единый транспортный билет',0,25,2,'Город',{T1:4,C1:2}],
      ['Новые скверы',1,18,3,'Район',{E1:14,E2:4,S2:3}],['Посадка деревьев',1,12,4,'Район',{E1:9,E2:6}],['Контроль выбросов',1,22,2,'Город',{E2:5,T2:-1}],
      ['Расширение школ',2,24,4,'Район',{S1:18}],['Общественные центры',2,20,3,'Район',{S1:3,S2:14}],['Спортивные площадки',2,10,1,'Район',{S2:8,B1:2}],
      ['Освещение улиц',3,12,1,'Район',{B1:12,B2:3}],['Безопасные переходы',3,10,1,'Район',{B2:12,T2:-2}],
      ['Цифровые услуги',4,22,2,'Город',{C1:7}],['Вывоз отходов',4,14,1,'Район',{C2:12,E2:2}],['Ремонт дворов',4,16,2,'Район',{C2:7,S2:4,B1:3}]
    ];
    const vector=e=>Object.fromEntries(keys.map(k=>[k,e[k]||0]));
    return {
      Районы:names.map((n,d)=>({'Район':n,'Население':[50000,70000,45000,55000,60000][d],...Object.fromEntries(keys.map((k,i)=>[k,rows[d][i]]))})),
      Мероприятия:specs.map(a=>({'Мероприятие':a[0],'Направление':categories[a[1]],'Стоимость':a[2],'Лаг':a[3],'Охват':a[4]})),
      Эффекты:specs.flatMap(a=>names.map(d=>({'Мероприятие':a[0],'Район':d,...vector(a[5])}))),
      Синергии:[{'Мера 1':'Автобусные полосы','Мера 2':'Умные остановки','Район':'*',...vector({T1:3})},{'Мера 1':'Освещение улиц','Мера 2':'Безопасные переходы','Район':'*',...vector({B2:3})}],
      Настройки:[{'Название набора':'Учебный город · синтетические данные','Бюджет':100,'Число решений':5}]
    };
  }
  const api={keys,weights,labels,categories,headers,num,clip,clone,validate,aggregate,evaluate,seed};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else host.AkimModel=api;
})(typeof globalThis!=='undefined'?globalThis:this);
