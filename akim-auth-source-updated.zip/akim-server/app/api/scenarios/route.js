import {auth} from '../../../lib/service.mjs';
import {getDatabase} from '../../../lib/db.mjs';
import {cityService} from '../../../lib/city-service.mjs';
import {consumeLimit} from '../../../lib/auth.mjs';
import {guarded,json,tokenFrom,assertOrigin,body} from '../../../lib/http.mjs';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export const GET=request=>guarded(async()=>{
  const user=await (await auth()).requireUser(tokenFrom(request));
  return json({scenarios:await cityService(await getDatabase()).list(user)});
});
export const POST=request=>guarded(async()=>{
  assertOrigin(request);
  const user=await (await auth()).requireUser(tokenFrom(request)), db=await getDatabase();
  await consumeLimit(db,'save-'+user.id,40);
  return json({scenario:await cityService(db).save(user,await body(request,16384))},201);
});
