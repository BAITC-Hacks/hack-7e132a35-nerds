import {auth} from '../../../lib/service.mjs';
import {getDatabase} from '../../../lib/db.mjs';
import {cityService} from '../../../lib/city-service.mjs';
import {guarded,json,tokenFrom} from '../../../lib/http.mjs';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export const GET=request=>guarded(async()=>{
  const user=await (await auth()).requireUser(tokenFrom(request));
  const dataset=await cityService(await getDatabase()).active();
  return json({user,dataset,aiConfigured:Boolean(process.env.OPENAI_API_KEY)});
});
