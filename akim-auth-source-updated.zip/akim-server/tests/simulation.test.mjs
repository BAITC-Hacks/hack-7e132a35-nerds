import test from 'node:test';
import assert from 'node:assert/strict';
import {Model,calculate,approvedSheets,improve} from '../lib/simulation.mjs';
import {analyzeScenario} from '../lib/ai.mjs';
const sheets=Model.seed();
const plan=[['Умные остановки','Северный'],['Посадка деревьев','Центральный'],['Спортивные площадки','Восточный'],['Освещение улиц','Южный'],['Вывоз отходов','Западный']].map(([measure,district])=>({measure,district}));
test('formula, fixed start, lag and weighted metrics',()=>{
  const r=calculate(sheets,plan),base=calculate(sheets,[],false);
  assert.equal(r.spent,58);assert.equal(r.directions.length,5);
  assert.deepEqual(base.before,r.before);
  assert.equal(r.values[0][0],43+7*7/8);
  assert.equal(r.after.score,Model.clip(.7*r.after.average+.3*r.after.worst-r.after.critical));
  assert.notEqual(r.after.score,base.after.score);
  assert.deepEqual(calculate(sheets,[...plan].reverse()).after,r.after);
});
test('reject five decisions in just one category, forged choices, overspend and incomplete plans',()=>{
  assert.throws(()=>calculate(sheets,sheets.Районы.map(d=>({measure:'Автобусные полосы',district:d.Район}))),/направлен/);
  assert.throws(()=>calculate(sheets,plan.slice(1)),/пяти/);
  assert.throws(()=>calculate(sheets,[{measure:'hack',district:'*'}]),/Неизвестная/);
  assert.throws(()=>calculate(sheets,null));
  const expensive=[['Единый транспортный билет','*'],['Контроль выбросов','*'],['Расширение школ','Восточный'],['Освещение улиц','Южный'],['Цифровые услуги','*']].map(([measure,district])=>({measure,district}));
  assert.throws(()=>calculate(sheets,expensive),/бюджет/);
});
test('dataset approval requires feasible five directions',()=>{
  const bad=Model.clone(sheets);bad.Настройки[0].Бюджет=1;assert.throws(()=>approvedSheets(bad),/Бюджет/);
  bad.Настройки[0].Бюджет=100;bad.Настройки[0]['Число решений']=4;assert.throws(()=>approvedSheets(bad),/пять/);
  assert.deepEqual(approvedSheets(sheets),sheets);
});
test('recommendation is recomputable, within budget and changes exactly one choice',()=>{
  const r=calculate(sheets,plan),rec=improve(sheets,plan,r);assert.ok(rec);
  assert.equal(rec.plan.filter((p,i)=>JSON.stringify(p)!==JSON.stringify(plan[i])).length,1);
  assert.deepEqual(calculate(sheets,rec.plan),rec.result);
  assert.ok(rec.result.after.score>r.after.score);assert.ok(rec.result.spent<=100);
});
test('cross-direction synergies and scale cap work',()=>{
  const p=[{measure:'Автобусные полосы',district:'Северный'},{measure:'Безопасные переходы',district:'Северный'}];
  const r=calculate(sheets,p,false);assert.equal(r.activeSynergies.length,1);assert.equal(r.values[0][0],43+12*.75+3);
  assert.ok(r.values.flat().every(v=>v>=0&&v<=100));
});
test('AI absent, failures and valid structured response remain separate from score',async()=>{
  const row={plan,result:calculate(sheets,plan)};
  assert.equal((await analyzeScenario(row,{sheets},{key:''})).status,'unavailable');
  assert.equal((await analyzeScenario(row,{sheets},{key:'test',fetcher:async()=>{throw Error('secret')}})).status,'unavailable');
  let sent;const sections={strengths:'Сильные стороны',risks:'Риски',tradeoffs:'Компромиссы',improvement:'Замена'};
  const result=await analyzeScenario(row,{sheets},{key:'test',fetcher:async(url,request)=>{sent=JSON.parse(request.body);return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify(sections)}]}]})};}});
  assert.equal(sent.store,false);assert.deepEqual(result.sections,sections);assert.ok(!('score' in result));
});
test('exact budget is valid and clipping occurs after all effects',()=>{
  const plan=[['Автобусные полосы','Северный'],['Контроль выбросов','*'],['Расширение школ','Восточный'],['Освещение улиц','Южный'],['Цифровые услуги','*']].map(([measure,district])=>({measure,district}));
  const s=Model.clone(sheets);s.Районы[0].T2=99;
  const r=calculate(s,plan);assert.equal(r.spent,100);assert.equal(r.values[0][1],100);
  assert.deepEqual(calculate(s,[...plan].reverse()).values,r.values);
});
test('AI refusals, incomplete output and malformed sections are not presented as analysis',async()=>{
  for(const data of [
    {status:'incomplete',output:[]},
    {status:'completed',output:[{type:'message',content:[{type:'refusal',refusal:'No'}]}]},
    {status:'completed',output:[{type:'message',content:[{type:'output_text',text:'{"strengths":123}'}]}]}
  ]){
    const out=await analyzeScenario({plan,result:calculate(sheets,plan)},{sheets},{key:'test',fetcher:async()=>({ok:true,json:async()=>data})});
    assert.equal(out.status,'unavailable');assert.ok(!out.sections);
  }
});
