CREATE TABLE IF NOT EXISTS datasets (
  id uuid PRIMARY KEY,
  name varchar(100) NOT NULL,
  sheets jsonb NOT NULL,
  formula_version text NOT NULL,
  created_by uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  active boolean NOT NULL DEFAULT false
);
CREATE UNIQUE INDEX IF NOT EXISTS datasets_one_active ON datasets(active) WHERE active;
CREATE TABLE IF NOT EXISTS scenarios (
  id uuid PRIMARY KEY,
  owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  dataset_id uuid NOT NULL REFERENCES datasets(id),
  formula_version text NOT NULL,
  title varchar(100) NOT NULL,
  plan jsonb NOT NULL,
  result jsonb NOT NULL,
  recommendation jsonb,
  analysis jsonb,
  created_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS scenarios_owner_date ON scenarios(owner_id,created_at DESC);
