import {getDatabase} from '../lib/db.mjs';
import {hashPassword,normalizeLogin} from '../lib/auth.mjs';
import {randomUUID} from 'node:crypto';
if(process.env.ADMIN_LOGIN&&process.env.ADMIN_PASSWORD){
  const db=await getDatabase();
  try{const login=normalizeLogin(process.env.ADMIN_LOGIN);
    if(!(await db.query('SELECT id FROM users WHERE login=$1',[login])).rows.length){
      const hash=await hashPassword(process.env.ADMIN_PASSWORD);
      await db.query('INSERT INTO users(id,login,display_name,password_hash,role) VALUES($1,$2,$3,$4,$5) ON CONFLICT(login) DO NOTHING',[randomUUID(),login,'Организатор',hash,'admin']);
      console.log('Organizer bootstrap complete.');
    }
  }finally{await db.close();}
}
