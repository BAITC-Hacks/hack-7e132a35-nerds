import {auth} from '../../../../lib/service.mjs';
import {getDatabase} from '../../../../lib/db.mjs';
import {cityService} from '../../../../lib/city-service.mjs';
import {guarded,json,tokenFrom,assertOrigin,body} from '../../../../lib/http.mjs';
export const runtime='nodejs';
export const POST=request=>guarded(async()=>{
  assertOrigin(request);
  const user=await (await auth()).requireUser(tokenFrom(request),['admin']);
  const dataset=await cityService(await getDatabase()).publish(user,await body(request,1024*1024));
  return json({dataset},201);
});
