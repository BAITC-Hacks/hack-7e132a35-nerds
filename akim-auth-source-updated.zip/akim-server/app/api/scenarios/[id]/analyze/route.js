import {auth} from '../../../../../lib/service.mjs';
import {getDatabase} from '../../../../../lib/db.mjs';
import {cityService} from '../../../../../lib/city-service.mjs';
import {analyzeScenario} from '../../../../../lib/ai.mjs';
import {consumeLimit} from '../../../../../lib/auth.mjs';
import {guarded,json,tokenFrom,assertOrigin} from '../../../../../lib/http.mjs';
export const runtime='nodejs';
export const maxDuration=60;
export const POST=(request,context)=>guarded(async()=>{
  assertOrigin(request);
  const user=await (await auth()).requireUser(tokenFrom(request)),db=await getDatabase();
  const {id}=await context.params,scenario=await cityService(db).owned(user,id);
  if(scenario.analysis?.status==='ready')return json({scenario});
  await consumeLimit(db,'ai-'+user.id,8);
  const dataset=(await db.query('SELECT * FROM datasets WHERE id=$1',[scenario.dataset_id])).rows[0];
  const analysis=await analyzeScenario(scenario,dataset);
  // A late failed request must not overwrite a successful concurrent explanation.
  await db.query(`UPDATE scenarios SET analysis=$1 WHERE id=$2 AND (analysis IS NULL OR analysis->>'status'<>'ready')`,[JSON.stringify(analysis),id]);
  return json({scenario:await cityService(db).owned(user,id)});
});
