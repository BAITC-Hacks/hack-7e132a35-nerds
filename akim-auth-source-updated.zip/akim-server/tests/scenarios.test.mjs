import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {randomUUID,randomBytes} from 'node:crypto';
import {Client} from 'pg';
import {cityService} from '../lib/city-service.mjs';
import {Model,calculate} from '../lib/simulation.mjs';
const db=new Client({connectionString:process.env.DATABASE_URL});await db.connect();
const schema='scenario_test_'+randomBytes(6).toString('hex');
const adapter={query:(...args)=>db.query(...args),transaction:async fn=>{await db.query('BEGIN');try{const r=await fn(db);await db.query('COMMIT');return r;}catch(e){await db.query('ROLLBACK');throw e;}}};
const service=cityService(adapter),admin={id:randomUUID(),role:'admin'},user={id:randomUUID(),role:'participant'},other={id:randomUUID(),role:'participant'};
const plan=[['Умные остановки','Северный'],['Посадка деревьев','Центральный'],['Спортивные площадки','Восточный'],['Освещение улиц','Южный'],['Вывоз отходов','Западный']].map(([measure,district])=>({measure,district}));
let count=0;async function check(name,fn){await fn();count++;console.log('PASS '+name);}
try{
  await db.query('CREATE SCHEMA '+schema);await db.query('SET search_path TO '+schema);
  for(const name of ['001_auth.sql','002_scenarios.sql'])await db.query(await fs.readFile(new URL('../db/'+name,import.meta.url),'utf8'));
  for(const [i,u] of [admin,user,other].entries())await db.query('INSERT INTO users(id,login,display_name,password_hash,role) VALUES($1,$2,$2,$3,$4)',[u.id,'user'+i,'test-only-not-a-hash',u.role]);
  let dataset,row;
  await check('participant cannot publish',async()=>{await assert.rejects(service.publish(user,{sheets:Model.seed()}),e=>e.status===403);});
  await check('organizer publishes one common dataset',async()=>{dataset=await service.publish(admin,{sheets:Model.seed()});assert.equal((await service.active()).id,dataset.id);});
  await check('forged score, cost and sheets ignored',async()=>{row=await service.save(user,{datasetId:dataset.id,plan,title:'Test',result:{after:{score:100}},spent:0,sheets:{}});assert.deepEqual(row.result,calculate(dataset.sheets,plan));assert.equal(row.result.spent,58);});
  await check('saved scenarios persist and are owner-only',async()=>{assert.equal((await service.list(user)).length,1);assert.equal((await service.list(other)).length,0);await assert.rejects(service.owned(other,row.id),e=>e.status===404);assert.equal((await service.owned(user,row.id)).id,row.id);});
  await check('invalid scenarios are not stored',async()=>{await assert.rejects(service.save(user,{datasetId:dataset.id,plan:plan.slice(1),title:'bad'}),e=>e.status===400);assert.equal((await service.list(user)).length,1);});
  await check('new round keeps history and rejects stale submissions',async()=>{const next=await service.publish(admin,{sheets:Model.seed()});assert.notEqual(next.id,dataset.id);assert.equal((await db.query('SELECT count(*) FROM datasets WHERE active')).rows[0].count,'1');await assert.rejects(service.save(user,{datasetId:dataset.id,plan,title:'stale'}),e=>e.status===409);assert.equal((await service.owned(user,row.id)).dataset_id,dataset.id);});
  console.log(count+' scenario database checks passed.');
}finally{await db.query('SET search_path TO public');await db.query('DROP SCHEMA '+schema+' CASCADE');await db.end();}
