import {randomBytes} from 'node:crypto';
import fs from 'node:fs';
const file=new URL('../.env.demo',import.meta.url);
fs.writeFileSync(file,`POSTGRES_PASSWORD=${randomBytes(24).toString('hex')}
ADMIN_LOGIN=organizer
ADMIN_PASSWORD=${randomBytes(18).toString('base64url')}
APP_ORIGIN=http://localhost:3000
ALLOW_HTTP_LOCALHOST=true
ALLOW_REGISTRATION=true
SESSION_HOURS=12
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
`,{flag:'wx',mode:0o600});
console.log('Created .env.demo with random passwords. Organizer login: organizer. Read ADMIN_PASSWORD locally in this file; do not publish it.');
