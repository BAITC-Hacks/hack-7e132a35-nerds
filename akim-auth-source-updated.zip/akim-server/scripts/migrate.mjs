import fs from 'node:fs/promises';
import {getDatabase} from '../lib/db.mjs';
import {Model,FORMULA_VERSION,SEED_ID,approvedSheets} from '../lib/simulation.mjs';
const db=await getDatabase();
try{await db.transaction(async tx=>{
  await tx.query('SELECT pg_advisory_xact_lock(854722)');
  for(const name of ['001_auth.sql','002_scenarios.sql'])await tx.query(await fs.readFile(new URL('../db/'+name,import.meta.url),'utf8'));
  const sheets=approvedSheets(Model.seed());
  await tx.query(`INSERT INTO datasets(id,name,sheets,formula_version,active)
    SELECT $1,$2,$3,$4,NOT EXISTS(SELECT 1 FROM datasets WHERE active)
    WHERE NOT EXISTS(SELECT 1 FROM datasets) ON CONFLICT DO NOTHING`,[SEED_ID,sheets.Настройки[0]['Название набора'],JSON.stringify(sheets),FORMULA_VERSION]);
});console.log('Auth, dataset and scenario migrations complete.');}finally{await db.close();}
